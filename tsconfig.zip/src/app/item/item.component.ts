import { Component, Input, Output,EventEmitter, OnInit } from '@angular/core';
import {Item} from '../item';


declare var window: any;


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
 
  formModal:any;
 editable = false;

  @Input() item!: Item;
  @Input() newItem!: string;
  @Output() putTodosEvent = new EventEmitter<{description:string, id:number}>();
  @Output() remove = new EventEmitter<Item>();
  @Output() updateStatus = new EventEmitter<Item>();

  constructor() { } 
  ngOnInit(): void {
    this.formModal = new window.bootstrap.Modal(
     document.getElementById("exampleModal")  
    );
  }

  edit(){
    this.formModal.show();
  }

  doSomething(){
    this.formModal.hide();
  }
  
  

  done(item: Item){
    item.done = !item.done
    console.log(item)

    // item.done = false;
  }


  updatePost(item: Item){
    this.updateStatus.emit(item);

  }

  saveItem(description: string){
    if(!description) return;
    this.editable = false;
    this.item.description = description;
  }
  handleSaveItem(description:string, id:number){
    this.saveItem(description)
    this.putTodosEvent.emit({description,id})


  }
  // handleEditItem(description:string, id:number){
    // this.editable = true;
    // this.putTodos.emit({ description, id })
  // }
  // 


}
